"""
hardware/selftest.py - a tiny 3-joint MuJoCo arm that swings by itself. Use it to check the whole
chain (MuJoCo -> launcher -> UDP -> board -> motors) without the Go2 code:

    python -m hardware.run_with_hardware hardware.selftest --host 192.168.0.15 \
        --joints j0,j1,j2 --send pos

The three motors should swing slowly. If they do, the launcher and the network are fine, and any
remaining problem is in how the Go2 example steps the simulation.
"""
import math
import time

import mujoco

XML = """
<mujoco>
  <option timestep="0.002" gravity="0 0 0"/>
  <worldbody>
    <body name="b1">
      <joint name="j0" type="hinge" axis="0 0 1" damping="0.3"/>
      <geom type="capsule" fromto="0 0 0 0.2 0 0" size="0.02" mass="0.5"/>
      <body name="b2" pos="0.2 0 0">
        <joint name="j1" type="hinge" axis="0 1 0" damping="0.3"/>
        <geom type="capsule" fromto="0 0 0 0.2 0 0" size="0.02" mass="0.5"/>
        <body name="b3" pos="0.2 0 0">
          <joint name="j2" type="hinge" axis="0 1 0" damping="0.3"/>
          <geom type="capsule" fromto="0 0 0 0.2 0 0" size="0.02" mass="0.5"/>
        </body>
      </body>
    </body>
  </worldbody>
  <actuator>
    <motor joint="j0" gear="1"/>
    <motor joint="j1" gear="1"/>
    <motor joint="j2" gear="1"/>
  </actuator>
</mujoco>
"""


def main(seconds=20.0):
    model = mujoco.MjModel.from_xml_string(XML)
    data = mujoco.MjData(model)
    t0 = time.perf_counter()
    while time.perf_counter() - t0 < seconds:
        t = data.time
        fade = min(1.0, t / 2.0)
        data.ctrl[:] = [0.4 * fade * math.sin(2 * math.pi * 0.3 * t),
                        0.3 * fade * math.sin(2 * math.pi * 0.3 * t + 1.0),
                        0.2 * fade * math.sin(2 * math.pi * 0.3 * t + 2.0)]
        mujoco.mj_step(model, data)
        time.sleep(model.opt.timestep)           # real time


if __name__ == "__main__":
    main()
