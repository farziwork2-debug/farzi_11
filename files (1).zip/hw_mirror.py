"""
hardware/hw_mirror.py - replicate the joint torques (or angles) of a running MuJoCo simulation on
real MyActuator motors through the Orange Pi 5 (board side: myact_ctl --mode udp).

Normally you do not import this yourself: run any example through hardware/run_with_hardware.py.
You can also use it directly inside your own loop:

    from hardware.hw_mirror import HardwareMirror
    hw = HardwareMirror(model, host="192.168.50.2",
                        joints=["FL_hip_joint", "FL_thigh_joint", "FL_calf_joint"],  # motor bus order
                        rated_nm=60.0, max_nm=6.0)
    ...
    mujoco.mj_step(model, data)
    hw.step(data)
    ...
    hw.close()

Torque per joint = data.qfrc_actuator + data.qfrc_applied at the joint's dof, i.e. whatever the
controller applied (motor actuators or direct generalized forces). Passive damping/friction of the
model are not included.
"""
import time

from .myact_udp import MyActBridge, POS, TORQUE, HOLD


def hinge_joint_names(model):
    """Names of all hinge joints of a MuJoCo model (these can be mapped to motors)."""
    import mujoco
    names = []
    for i in range(model.njnt):
        if model.jnt_type[i] == mujoco.mjtJoint.mjJNT_HINGE:
            names.append(mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_JOINT, i))
    return names


class HardwareMirror:
    def __init__(self, model, host, joints, rated_nm=60.0, max_nm=None, port=5005, mode="torque",
                 rate_hz=200.0, dry_run=False, verbose=True):
        if mode not in ("torque", "pos"):
            raise ValueError("mode must be 'torque' or 'pos'")
        self.names = list(joints)
        try:
            self.dof = [int(model.joint(n).dofadr[0]) for n in self.names]
            self.qadr = [int(model.joint(n).qposadr[0]) for n in self.names]
        except Exception as e:
            avail = ", ".join(hinge_joint_names(model))
            raise SystemExit(f"joint lookup failed ({e}).\nHinge joints in this model: {avail}")
        n = len(self.names)
        rated = rated_nm if isinstance(rated_nm, (list, tuple)) else [rated_nm] * n
        if len(rated) != n:
            raise ValueError("rated_nm needs one value or one per joint")
        self.rated = [float(r) for r in rated]
        if max_nm is None:
            max_nm = [0.1 * r for r in self.rated]                  # default: 10 % of rated torque
        elif not isinstance(max_nm, (list, tuple)):
            max_nm = [max_nm] * n
        self.max_nm = [abs(float(m)) for m in max_nm]
        self.mode = mode
        self.dry_run = dry_run
        self.verbose = verbose
        self.period = 1.0 / rate_hz
        self.t_next = 0.0
        self.t_report = 0.0
        self.peak = [0.0] * n
        self.clipped = 0
        self.extra = ""                                             # extra text for the status line
        self.state = None                                           # latest feedback from the motors
        self.bridge = None if dry_run else MyActBridge(host, n, port)

    def step(self, data, tau_nm=None):
        """Call after every simulation step. Sends at rate_hz."""
        now = time.perf_counter()
        if now < self.t_next:
            return self.state
        self.t_next = max(self.t_next + self.period, now - self.period)   # fixed rate, no drift

        if tau_nm is None:
            tau_nm = [float(data.qfrc_actuator[d]) + float(data.qfrc_applied[d]) for d in self.dof]
        tau = []
        for i, t in enumerate(tau_nm):
            t = float(t)
            self.peak[i] = max(self.peak[i], abs(t))
            if abs(t) > self.max_nm[i]:
                self.clipped += 1
                t = self.max_nm[i] if t > 0 else -self.max_nm[i]
            tau.append(t)

        if self.bridge is not None:
            if self.mode == "torque":
                self.bridge.send(mode=TORQUE, tau_nm=tau, rated_nm=self.rated)
            else:
                self.bridge.send(mode=POS, q=[float(data.qpos[a]) for a in self.qadr])
            st = self.bridge.poll()
            if st:
                self.state = st

        if self.verbose and now - self.t_report > 1.0:
            self.t_report = now
            msg = " ".join(f"{n.replace('_joint', '')}:{t:+.2f}Nm" for n, t in zip(self.names, tau))
            if self.state:
                msg += " | motors " + " ".join(f"{p}/{m}" for p, m in zip(self.state.phase, self.state.mode))
            msg += " | peak(Nm) " + " ".join(f"{p:.1f}" for p in self.peak) + f" | clipped={self.clipped}"
            if self.extra:
                msg += " | " + self.extra
            print(("[dry-run] " if self.dry_run else "[hw] ") + msg, flush=True)
        return self.state

    def close(self):
        """Send HOLD a few times, then stop sending (the board's watchdog then stops the motors)."""
        if self.bridge is None:
            return
        for _ in range(10):
            self.bridge.send(mode=HOLD)
            time.sleep(0.01)
